import { CONFIG } from './config.js';

function pickBand(value, list) {
  return list.find(item => value <= item.max) || list[list.length - 1];
}

function clamp(num, min, max) {
  return Math.max(min, Math.min(max, num));
}

export function hesaplaRisk(veri) {
  const borcLimit = veri.toplamLimit > 0 ? (veri.toplamBorc / veri.toplamLimit) * 100 : 0;
  const gelirOdeme = veri.netGelir > 0 ? (veri.aylikOdeme / veri.netGelir) * 100 : 999;

  const borcBand = pickBand(borcLimit, CONFIG.borcLimitYorumlari);
  const gelirBand = pickBand(gelirOdeme, CONFIG.gelirOdemeYorumlari);

  let skor = 70;
  skor += borcBand.etki;
  skor += gelirBand.etki;

  if (veri.aktifGecikme) skor += CONFIG.etkiler.aktifGecikme;
  if (veri.enYuksekGecikmeGun >= 30) skor += CONFIG.etkiler.gecikmeGun30Ustu;
  if (veri.gecikmeAdedi >= 2) skor += CONFIG.etkiler.gecikmeAdet2Ustu;
  if (veri.takip === 'eski') skor += CONFIG.etkiler.takipEski;
  if (veri.takip === 'yeni') skor += CONFIG.etkiler.takipYeni;
  if (veri.vergiLevhasi) skor += CONFIG.etkiler.vergiLevhasi;

  if (!veri.aktifGecikme && veri.takip === 'yok' && borcLimit <= 50 && gelirOdeme <= 45) {
    skor += CONFIG.etkiler.temizProfil;
  }

  if (veri.toplamLimit <= 25000 && borcLimit >= 75) {
    skor += CONFIG.etkiler.limitDusukAmaBorcYuksek;
  }

  skor = clamp(skor, 0, 100);

  let sonuc = 'ZOR';
  if (skor >= CONFIG.sonucLimitleri.cikar && !veri.aktifGecikme && veri.takip !== 'yeni') sonuc = 'ÇIKAR';
  if (skor < CONFIG.sonucLimitleri.zor || (veri.aktifGecikme && borcLimit > 80) || veri.takip === 'yeni') sonuc = 'ÇIKMAZ';

  let riskSeviyesi = 'Orta';
  if (sonuc === 'ÇIKAR') riskSeviyesi = 'Düşük / Orta';
  if (sonuc === 'ÇIKMAZ') riskSeviyesi = 'Yüksek';

  const puan = Math.round(CONFIG.tahminiPuan.min + (skor / 100) * (CONFIG.tahminiPuan.max - CONFIG.tahminiPuan.min));
  const puanBandi = puanBandiGetir(puan);

  return {
    skor,
    sonuc,
    riskSeviyesi,
    tahminiPuan: puan,
    puanBandi,
    borcLimit: Number(borcLimit.toFixed(1)),
    gelirOdeme: Number(gelirOdeme.toFixed(1)),
    borcLimitYorumu: borcBand.yorum,
    gelirOdemeYorumu: gelirBand.yorum
  };
}

export function puanBandiGetir(puan) {
  if (puan <= 999) return `${puan} • Çok Zayıf`;
  if (puan <= 1199) return `${puan} • Zayıf`;
  if (puan <= 1349) return `${puan} • Sınırda / Orta Alt`;
  if (puan <= 1499) return `${puan} • Orta İyi`;
  if (puan <= 1699) return `${puan} • Güçlü`;
  return `${puan} • Çok Güçlü`;
}
