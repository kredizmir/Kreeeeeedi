export const CONFIG = {
  sonucLimitleri: {
    cikar: 78,
    zor: 50
  },
  tahminiPuan: {
    min: 850,
    max: 1750
  },
  borcLimitYorumlari: [
    { max: 30, etki: 20, yorum: 'çok iyi' },
    { max: 50, etki: 10, yorum: 'iyi' },
    { max: 70, etki: -8, yorum: 'orta risk' },
    { max: 90, etki: -22, yorum: 'yüksek risk' },
    { max: 9999, etki: -38, yorum: 'çok yüksek risk' }
  ],
  gelirOdemeYorumlari: [
    { max: 30, etki: 16, yorum: 'rahat' },
    { max: 45, etki: 8, yorum: 'kabul edilebilir' },
    { max: 60, etki: -8, yorum: 'baskılı' },
    { max: 75, etki: -18, yorum: 'yüksek baskı' },
    { max: 9999, etki: -30, yorum: 'kritik baskı' }
  ],
  etkiler: {
    aktifGecikme: -42,
    gecikmeGun30Ustu: -20,
    gecikmeAdet2Ustu: -14,
    takipEski: -20,
    takipYeni: -52,
    vergiLevhasi: 8,
    temizProfil: 14,
    limitDusukAmaBorcYuksek: -12
  }
};
