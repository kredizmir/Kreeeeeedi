export function yorumUret(veri, sonuc) {
  const guclu = [];
  const zayif = [];
  const kritik = [];
  const aksiyon = [];
  const genelOzet = [];

  genelOzet.push(`Tahmini KKB bandı: ${sonuc.puanBandi}`);
  genelOzet.push(`Borç / limit oranı: %${sonuc.borcLimit} (${sonuc.borcLimitYorumu})`);
  genelOzet.push(`Gelir / aylık ödeme baskısı: %${sonuc.gelirOdeme} (${sonuc.gelirOdemeYorumu})`);

  if (veri.takip === 'yok') guclu.push('Yakın dönem takip görünmüyor.');
  if (!veri.aktifGecikme) guclu.push('Güncel gecikme görünmüyor.');
  if (sonuc.borcLimit <= 50) guclu.push('Kart ve KMH kullanımı dengeli tarafta.');
  if (sonuc.gelirOdeme <= 45) guclu.push('Aylık ödeme yükü gelire göre yönetilebilir görünüyor.');
  if (veri.vergiLevhasi) guclu.push('Vergi levhası olması bazı finans kanallarında avantaj sağlayabilir.');

  if (veri.takip === 'eski') {
    zayif.push('Eski takip geçmişi iz bırakıyor.');
    kritik.push('Eski takip kapalı olsa bile bankalar bunu negatif okuyabilir.');
    aksiyon.push('Takip geçmişi eskiyse temiz son 6-12 ay ödeme düzeni öne çıkarılmalı.');
  }
  if (veri.takip === 'yeni') {
    zayif.push('Son 36 ay içinde takip geçmişi var.');
    kritik.push('Yakın dönem kanuni/icra takibi ciddi kırmızı bayraktır.');
    aksiyon.push('Yakın dönem takip varsa banka tarafında acele yerine temizlik ve süre kazanmak gerekir.');
  }
  if (veri.aktifGecikme) {
    zayif.push('Aktif gecikme mevcut.');
    kritik.push('Güncel gecikme doğrudan red sebebi yaratabilir.');
    aksiyon.push('Öncelik aktif gecikmenin tamamen kapatılması olmalı.');
  }
  if (veri.gecikmeAdedi >= 2) {
    zayif.push('Son 12 ay gecikme sıklığı olumsuz.');
    aksiyon.push('En az 3-4 ay düzenli ödeme disiplini gösterilmeli.');
  }
  if (veri.enYuksekGecikmeGun >= 30) {
    zayif.push('30 gün üzeri gecikme geçmişi risk yükseltiyor.');
    kritik.push('Gecikmenin süresi uzadıkça puan ve onay ihtimali daha sert etkilenir.');
  }
  if (sonuc.borcLimit > 70) {
    zayif.push('Borç / limit oranı yüksek.');
    kritik.push('Kart ve KMH tarafında yoğun kullanım var.');
    aksiyon.push('Kart/KMH oranı %50 altına çekilirse profil belirgin toparlar.');
  }
  if (sonuc.borcLimit > 90) {
    kritik.push('Borç / limit kritik seviyede.');
    aksiyon.push('Küçük dahi olsa borç kapatma yapmadan başvuru zorlanabilir.');
  }
  if (sonuc.gelirOdeme > 60) {
    zayif.push('Aylık ödeme yükü gelire göre baskılı.');
    aksiyon.push('Peşinat artırmak veya istenen kredi tutarını düşürmek daha doğru olur.');
  }
  if (!aksiyon.length) {
    aksiyon.push('Mevcut düzen korunup uygun banka kanalında ön değerlendirme yapılabilir.');
  }

  const krediYorumu = krediYorumuUret(veri, sonuc);
  const kisaKarar = kisaKararUret(veri, sonuc);

  return {
    genelOzet,
    guclu: guclu.length ? guclu : ['Öne çıkan güçlü veri sınırlı.'],
    zayif: zayif.length ? zayif : ['Belirgin negatif unsur sınırlı görünüyor.'],
    kritik: kritik.length ? kritik : ['Kritik kırmızı bayrak görünmüyor.'],
    aksiyon,
    krediYorumu,
    kisaKarar
  };
}

function krediYorumuUret(veri, sonuc) {
  if (sonuc.sonuc === 'ÇIKAR') {
    return 'Taşıt kredisi tarafında profil temkinli olumlu görünüyor. Güncel gecikme yoksa ve borç/limit dengesi korunursa uygun banka kanalında değerlendirme şansı yüksektir.';
  }
  if (sonuc.sonuc === 'ZOR') {
    return 'Taşıt kredisi tamamen imkansız görünmüyor ancak profil gri alanda. Eski takip, gecikme izi veya yüksek kullanım oranı nedeniyle daha seçici bankalarda zorlanabilir; peşinat artırımı ve borç azaltımı sonucu güçlendirir.';
  }
  return 'Taşıt kredisi tarafında profil şu an olumsuz tarafta. Aktif gecikme, yakın takip veya çok yüksek borç baskısı nedeniyle mevcut haliyle bankadan çıkma ihtimali zayıf görünüyor.';
}

function kisaKararUret(veri, sonuc) {
  if (sonuc.sonuc === 'ÇIKAR') {
    return 'Ön değerlendirme sonucu: ÇIKAR. Profil temiz sayılabilecek tarafta; uygun banka ve doğru kredi tutarıyla olumlu ilerleme ihtimali var.';
  }
  if (sonuc.sonuc === 'ZOR') {
    return 'Ön değerlendirme sonucu: ZOR. Dosya tamamen olumsuz değil ancak risk unsurları nedeniyle destekleyici adımlar olmadan süreç zorlanabilir.';
  }
  return 'Ön değerlendirme sonucu: ÇIKMAZ. Mevcut tabloda aktif riskler ağır basıyor; önce gecikme, takip ve yüksek kullanım tarafı toparlanmalı.';
}

export function whatsappMetniUret(adSoyad, sonuc, yorum) {
  const isim = adSoyad?.trim() || 'Müşteri';
  return `${isim} için ön değerlendirme\n\nTahmini KKB Bandı: ${sonuc.puanBandi}\nRisk Seviyesi: ${sonuc.riskSeviyesi}\nSonuç: ${sonuc.sonuc}\nBorç/Limit: %${sonuc.borcLimit}\nGelir/Ödeme: %${sonuc.gelirOdeme}\n\nKısa Karar:\n${yorum.kisaKarar}`;
}
