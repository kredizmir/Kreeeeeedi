function fillList(id, items) {
  const el = document.getElementById(id);
  el.innerHTML = '';
  items.forEach(item => {
    const li = document.createElement('li');
    li.textContent = item;
    el.appendChild(li);
  });
}

export function renderResult(veri, sonuc, yorum) {
  document.getElementById('emptyState').classList.add('hidden');
  document.getElementById('resultArea').classList.remove('hidden');

  document.getElementById('puanBandi').textContent = sonuc.puanBandi;
  document.getElementById('riskSeviyesi').textContent = sonuc.riskSeviyesi;

  const sonucEl = document.getElementById('sonucEtiketi');
  sonucEl.textContent = sonuc.sonuc;
  sonucEl.className = '';
  if (sonuc.sonuc === 'ÇIKAR') sonucEl.classList.add('verdict-cikar');
  if (sonuc.sonuc === 'ZOR') sonucEl.classList.add('verdict-zor');
  if (sonuc.sonuc === 'ÇIKMAZ') sonucEl.classList.add('verdict-cikmaz');

  fillList('genelOzet', yorum.genelOzet);
  fillList('gucluTaraflar', yorum.guclu);
  fillList('zayifTaraflar', yorum.zayif);
  fillList('kritikTespitler', yorum.kritik);
  fillList('aksiyonlar', yorum.aksiyon);

  document.getElementById('krediYorumu').textContent = yorum.krediYorumu;
  document.getElementById('kisaKarar').textContent = yorum.kisaKarar;
}

export function resetResult() {
  document.getElementById('emptyState').classList.remove('hidden');
  document.getElementById('resultArea').classList.add('hidden');
}
