import { hesaplaRisk } from './engine.js';
import { yorumUret, whatsappMetniUret } from './commentary.js';
import { renderResult, resetResult } from './ui.js';

const form = document.getElementById('riskForm');
const demoBtn = document.getElementById('demoBtn');
const resetBtn = document.getElementById('resetBtn');
const copyBtn = document.getElementById('copyBtn');

let sonMetin = '';

function num(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

function formVerisiAl() {
  return {
    adSoyad: form.adSoyad.value || '',
    takip: form.takip.value,
    gecikmeAdedi: num(form.gecikmeAdedi.value),
    enYuksekGecikmeGun: num(form.enYuksekGecikmeGun.value),
    aktifGecikme: form.aktifGecikme.value === 'evet',
    toplamLimit: num(form.toplamLimit.value),
    toplamBorc: num(form.toplamBorc.value),
    netGelir: num(form.netGelir.value),
    aylikOdeme: num(form.aylikOdeme.value),
    vergiLevhasi: form.vergiLevhasi.value === 'evet',
    istenenKredi: num(form.istenenKredi.value)
  };
}

function kaydet() {
  localStorage.setItem('kkbForm', JSON.stringify(Object.fromEntries(new FormData(form).entries())));
}

function yukle() {
  const raw = localStorage.getItem('kkbForm');
  if (!raw) return;
  const data = JSON.parse(raw);
  Object.entries(data).forEach(([key, value]) => {
    if (form[key]) form[key].value = value;
  });
}

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const veri = formVerisiAl();
  const sonuc = hesaplaRisk(veri);
  const yorum = yorumUret(veri, sonuc);
  renderResult(veri, sonuc, yorum);
  sonMetin = whatsappMetniUret(veri.adSoyad, sonuc, yorum);
  kaydet();
});

copyBtn.addEventListener('click', async () => {
  if (!sonMetin) return alert('Önce analiz oluştur.');
  try {
    await navigator.clipboard.writeText(sonMetin);
    alert('Metin kopyalandı.');
  } catch {
    alert('Kopyalama başarısız oldu.');
  }
});

demoBtn.addEventListener('click', () => {
  form.adSoyad.value = 'Demo Müşteri';
  form.takip.value = 'eski';
  form.gecikmeAdedi.value = '1';
  form.enYuksekGecikmeGun.value = '12';
  form.aktifGecikme.value = 'hayir';
  form.toplamLimit.value = '220000';
  form.toplamBorc.value = '118000';
  form.netGelir.value = '65000';
  form.aylikOdeme.value = '24000';
  form.vergiLevhasi.value = 'evet';
  form.istenenKredi.value = '350000';
});

resetBtn.addEventListener('click', () => {
  form.reset();
  localStorage.removeItem('kkbForm');
  sonMetin = '';
  resetResult();
});

yukle();
