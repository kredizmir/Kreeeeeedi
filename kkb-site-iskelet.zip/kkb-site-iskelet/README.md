# KKB / Findeks Ön Değerlendirme İskeleti

## Nasıl açılır?
- `index.html` dosyasını tarayıcıda aç
- veya klasörü GitHub reposuna atıp GitHub Pages ile yayınla

## Dosya yapısı
- `index.html` : arayüz
- `css/style.css` : tasarım
- `js/config.js` : sabit kurallar
- `js/engine.js` : hesap motoru
- `js/commentary.js` : yorum üretimi
- `js/ui.js` : ekrana basma
- `js/main.js` : form yönetimi

## Mantık
- Karar motoru kural tabanlıdır
- Aynı veri aynı sonucu verir
- `config.js` içinden eşikleri değiştirebilirsin

## GitHub Pages
1. Yeni repo aç
2. Dosyaları repoya yükle
3. Settings > Pages
4. Branch: main / root seç
5. Save
6. Verilen linkten aç
